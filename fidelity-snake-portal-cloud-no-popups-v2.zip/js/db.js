/* Fidelity Services Group - Eswatini (Bigbend) Snake Catchers Portal — SQLite database (sql.js) + authentication
   Schema: optional-backend/database/schema.sql
   The live DB is an in-memory SQLite instance, persisted to IndexedDB after every write.
   Admins can download a real .sqlite file from Settings. */

const CONFIG = {
  appName: 'Fidelity Services Group - Eswatini (Bigbend) Snake Catchers Portal',
  controlRoom: '8002333',
  maxFailedLogins: 5,
  lockSeconds: 60,
  defaultAdmin: { username: 'Mongi', name: 'Mongi Mazibuko', empNo: 'FSG-496', password: 'Toor007' },
  // Real-time WebSocket hub. Leave empty for local-only.
  // After deploying realtime-worker: 'wss://fidelity-snake-realtime.<account>.workers.dev/ws'
  wsUrl: '',
  sqlWasmCdn: 'https://cdnjs.cloudflare.com/ajax/libs/sql.js/1.10.3/'
};

const DBLocal = (() => {
  let SQL = null;
  let sqlite = null;       // SQL.Database
  let ready = null;        // Promise
  let persistTimer = null;
  const IDB_NAME = 'fidelity_adt_snake_sqlite';
  const IDB_STORE = 'files';
  const IDB_KEY = 'portal.sqlite';

  /* ---------- IndexedDB blob store for the .sqlite file ---------- */
  function idbOpen() {
    return new Promise((res, rej) => {
      const r = indexedDB.open(IDB_NAME, 2);
      r.onupgradeneeded = () => {
        const d = r.result;
        if (!d.objectStoreNames.contains(IDB_STORE)) d.createObjectStore(IDB_STORE);
        if (!d.objectStoreNames.contains('photos')) d.createObjectStore('photos');
      };
      r.onsuccess = () => res(r.result);
      r.onerror = () => rej(r.error);
    });
  }
  async function photoPut(id, dataUrl) {
    if (!id) return;
    const d = await idbOpen();
    return new Promise((res, rej) => {
      const t = d.transaction('photos', 'readwrite');
      if (dataUrl) t.objectStore('photos').put(dataUrl, id);
      else t.objectStore('photos').delete(id);
      t.oncomplete = () => res();
      t.onerror = () => rej(t.error);
    });
  }
  async function photoGet(id) {
    const d = await idbOpen();
    return new Promise((res, rej) => {
      const t = d.transaction('photos', 'readonly');
      const rq = t.objectStore('photos').get(id);
      rq.onsuccess = () => res(rq.result || null);
      rq.onerror = () => rej(rq.error);
    });
  }
  async function photoDel(id) {
    const d = await idbOpen();
    return new Promise((res, rej) => {
      const t = d.transaction('photos', 'readwrite');
      t.objectStore('photos').delete(id);
      t.oncomplete = () => res();
      t.onerror = () => rej(t.error);
    });
  }
  async function idbGet() {
    const d = await idbOpen();
    return new Promise((res, rej) => {
      const t = d.transaction(IDB_STORE, 'readonly');
      const rq = t.objectStore(IDB_STORE).get(IDB_KEY);
      rq.onsuccess = () => res(rq.result || null);
      rq.onerror = () => rej(rq.error);
    });
  }
  async function idbPut(u8) {
    const d = await idbOpen();
    return new Promise((res, rej) => {
      const t = d.transaction(IDB_STORE, 'readwrite');
      t.objectStore(IDB_STORE).put(u8, IDB_KEY);
      t.oncomplete = () => res();
      t.onerror = () => rej(t.error);
    });
  }

  /* ---------- schema ---------- */
  const SCHEMA = `
    PRAGMA foreign_keys = ON;
    CREATE TABLE IF NOT EXISTS users (
      key TEXT PRIMARY KEY,
      username TEXT NOT NULL,
      name TEXT NOT NULL DEFAULT '',
      emp_no TEXT NOT NULL DEFAULT '',
      role TEXT NOT NULL DEFAULT 'user',
      salt TEXT NOT NULL,
      hash TEXT NOT NULL,
      created TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS reports (
      id TEXT PRIMARY KEY,
      catcher TEXT NOT NULL DEFAULT '',
      emp_no TEXT NOT NULL DEFAULT '',
      lat REAL,
      lng REAL,
      release_lat REAL,
      release_lng REAL,
      site TEXT NOT NULL DEFAULT '',
      release_loc TEXT NOT NULL DEFAULT '',
      description TEXT NOT NULL DEFAULT '',
      status TEXT NOT NULL DEFAULT 'Captured',
      captured_at TEXT,
      released_at TEXT,
      created_by TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL,
      environment TEXT NOT NULL DEFAULT '',
      photo TEXT,
      has_photo INTEGER NOT NULL DEFAULT 0
    );
    CREATE TABLE IF NOT EXISTS activity_log (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      at TEXT NOT NULL,
      username TEXT NOT NULL DEFAULT '',
      action TEXT NOT NULL,
      detail TEXT NOT NULL DEFAULT '',
      report_id TEXT
    );
    CREATE TABLE IF NOT EXISTS meta (
      k TEXT PRIMARY KEY,
      v TEXT
    );
    CREATE INDEX IF NOT EXISTS idx_reports_captured ON reports(captured_at);
    CREATE INDEX IF NOT EXISTS idx_reports_status ON reports(status);
    CREATE INDEX IF NOT EXISTS idx_reports_created_by ON reports(created_by);
    CREATE INDEX IF NOT EXISTS idx_activity_at ON activity_log(at);
    CREATE INDEX IF NOT EXISTS idx_activity_user ON activity_log(username);
  `;

  function schedulePersist() {
    clearTimeout(persistTimer);
    persistTimer = setTimeout(() => { persist().catch(() => {}); }, 250);
  }

  async function persist() {
    if (!sqlite) return;
    const data = sqlite.export();
    await idbPut(data);
  }

  /* ---------- init / migrate from old object-store IndexedDB ---------- */
  function loadScript(src) {
    return new Promise((res, rej) => {
      const el = document.createElement('script'); el.src = src; el.async = true; el.setAttribute('data-cfasync', 'false');
      el.onload = res; el.onerror = () => rej(new Error('Could not load ' + src));
      document.head.appendChild(el);
    });
  }
  async function loadSqlJs() {
    if (SQL) return SQL;
    const bases = [CONFIG.sqlWasmCdn, 'https://cdn.jsdelivr.net/npm/sql.js@1.10.3/dist/'];
    let lastErr = null;
    for (let i = 0; i < bases.length; i++) {
      try {
        if (typeof initSqlJs !== 'function') await loadScript(bases[i] + 'sql-wasm.js');
        SQL = await initSqlJs({ locateFile: file => bases[i] + file });
        return SQL;
      } catch (e) { lastErr = e; window.initSqlJs = undefined; try { delete window.initSqlJs; } catch (x) { /* ignore */ } }
    }
    throw new Error('The SQLite engine (sql.js) could not be loaded. Check the internet connection and reload. (' + (lastErr && lastErr.message || '') + ')');
  }

  async function migrateLegacy() {
    // Old portal stored users/reports in object stores under fidelity_adt_snake
    return new Promise(resolve => {
      const r = indexedDB.open('fidelity_adt_snake', 1);
      r.onerror = () => resolve(null);
      r.onupgradeneeded = () => { /* don't create if missing */ };
      r.onsuccess = () => {
        const d = r.result;
        if (!d.objectStoreNames.contains('users') || !d.objectStoreNames.contains('reports')) {
          d.close();
          return resolve(null);
        }
        const out = { users: [], reports: [] };
        const t = d.transaction(['users', 'reports'], 'readonly');
        t.objectStore('users').getAll().onsuccess = e => { out.users = e.target.result || []; };
        t.objectStore('reports').getAll().onsuccess = e => { out.reports = e.target.result || []; };
        t.oncomplete = () => { d.close(); resolve(out); };
        t.onerror = () => { d.close(); resolve(null); };
      };
    });
  }

  function applySchema(db) {
    db.run(SCHEMA);
    // Soft migrations for existing files
    try { db.run('ALTER TABLE reports ADD COLUMN has_photo INTEGER NOT NULL DEFAULT 0'); } catch (e) { /* exists */ }
    try { db.run("ALTER TABLE reports ADD COLUMN environment TEXT NOT NULL DEFAULT ''"); } catch (e) { /* exists */ }
    try {
      db.run(`CREATE TABLE IF NOT EXISTS activity_log (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        at TEXT NOT NULL,
        username TEXT NOT NULL DEFAULT '',
        action TEXT NOT NULL,
        detail TEXT NOT NULL DEFAULT '',
        report_id TEXT
      )`);
    } catch (e) { /* exists */ }
  }

  function insertUserRow(db, u) {
    db.run(
      `INSERT OR REPLACE INTO users (key, username, name, emp_no, role, salt, hash, created)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [u.key, u.username, u.name || '', u.empNo || u.emp_no || '', u.role || 'user', u.salt, u.hash, u.created || new Date().toISOString()]
    );
  }

  function insertReportRow(db, r) {
    const hasPhoto = !!(r.photo || r.has_photo);
    // Keep SQLite lean: only store tiny markers; full photos live in IndexedDB photos store
    const photoCol = hasPhoto ? 'blob:' : null;
    db.run(
      `INSERT OR REPLACE INTO reports
        (id, catcher, emp_no, lat, lng, release_lat, release_lng, site, release_loc,
         description, status, captured_at, released_at, created_by, created_at, environment, photo, has_photo)
       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
      [
        r.id, r.catcher || '', r.empNo || r.emp_no || '',
        r.lat != null ? r.lat : null, r.lng != null ? r.lng : null,
        r.releaseLat != null ? r.releaseLat : (r.release_lat != null ? r.release_lat : null),
        r.releaseLng != null ? r.releaseLng : (r.release_lng != null ? r.release_lng : null),
        r.site || '', r.releaseLoc || r.release_loc || '',
        r.description || '', r.status === 'Released' ? 'Released' : 'Captured',
        r.capturedAt || r.captured_at || null,
        r.releasedAt || r.released_at || null,
        r.createdBy || r.created_by || '',
        r.createdAt || r.created_at || new Date().toISOString(),
        r.environment || '',
        photoCol,
        hasPhoto ? 1 : 0
      ]
    );
  }

  function rowUser(r) {
    if (!r) return null;
    return {
      key: r[0], username: r[1], name: r[2], empNo: r[3], role: r[4],
      salt: r[5], hash: r[6], created: r[7]
    };
  }
  function rowReport(r) {
    if (!r) return null;
    return {
      id: r[0], catcher: r[1], empNo: r[2],
      lat: r[3], lng: r[4], releaseLat: r[5], releaseLng: r[6],
      site: r[7], releaseLoc: r[8], description: r[9], status: r[10],
      capturedAt: r[11], releasedAt: r[12], createdBy: r[13], createdAt: r[14],
      environment: r[15] || '',
      photo: r[16] && r[16] !== 'blob:' ? r[16] : null,
      has_photo: !!(r[17] || (r[16] && r[16] !== 'blob:'))
    };
  }
  async function attachPhoto(rep) {
    if (!rep) return rep;
    if (rep.photo && String(rep.photo).startsWith('data:')) return rep;
    const p = await photoGet(rep.id);
    if (p) { rep.photo = p; rep.has_photo = true; }
    return rep;
  }

  async function init() {
    await loadSqlJs();
    const existing = await idbGet();
    if (existing && existing.byteLength) {
      sqlite = new SQL.Database(new Uint8Array(existing));
      applySchema(sqlite);
    } else {
      sqlite = new SQL.Database();
      applySchema(sqlite);
      const legacy = await migrateLegacy();
      if (legacy && ((legacy.users && legacy.users.length) || (legacy.reports && legacy.reports.length))) {
        for (const u of legacy.users || []) insertUserRow(sqlite, u);
        for (const r of legacy.reports || []) insertReportRow(sqlite, r);
        await persist();
      }
    }
  }

  function ensure() {
    if (!ready) ready = init();
    return ready;
  }

  /* ---------- hashing ---------- */
  function rnd() {
    const a = new Uint8Array(16); crypto.getRandomValues(a);
    return Array.from(a, b => b.toString(16).padStart(2, '0')).join('');
  }
  async function hash(pw, salt) {
    const data = new TextEncoder().encode(salt + ':' + pw);
    if (window.crypto && crypto.subtle) {
      let buf = await crypto.subtle.digest('SHA-256', data);
      for (let i = 0; i < 5000; i++) buf = await crypto.subtle.digest('SHA-256', buf);
      return Array.from(new Uint8Array(buf), b => b.toString(16).padStart(2, '0')).join('');
    }
    throw new Error('Secure context (HTTPS) required for password hashing.');
  }

  /* ---------- users ---------- */
  const keyOf = u => String(u).trim().toLowerCase();

  async function ensureSeed() {
    await ensure();
    const cnt = sqlite.exec('SELECT COUNT(*) FROM users');
    const n = cnt[0] ? cnt[0].values[0][0] : 0;
    if (n === 0) {
      const a = CONFIG.defaultAdmin;
      await createUser({ username: a.username, name: a.name, empNo: a.empNo, password: a.password, role: 'admin' });
    }
    if (navigator.storage && navigator.storage.persist) navigator.storage.persist().catch(() => {});
  }

  async function createUser({ username, name, empNo, password, role }) {
    await ensure();
    const key = keyOf(username);
    if (!key) throw new Error('Username is required.');
    if (!/^[a-z0-9._-]{3,30}$/.test(key)) throw new Error('Username: 3-30 letters, numbers, dot, dash or underscore.');
    if (!password || password.length < 6) throw new Error('Password must be at least 6 characters.');
    const exists = sqlite.exec('SELECT 1 FROM users WHERE key = ?', [key]);
    if (exists.length && exists[0].values.length) throw new Error('That username already exists.');
    const salt = rnd();
    const h = await hash(password, salt);
    insertUserRow(sqlite, {
      key, username: username.trim(), name: (name || username).trim(), empNo: (empNo || '').trim(),
      role: role === 'admin' ? 'admin' : 'user', salt, hash: h, created: new Date().toISOString()
    });
    schedulePersist();
  }

  async function setPassword(username, password) {
    await ensure();
    if (!password || password.length < 6) throw new Error('Password must be at least 6 characters.');
    const u = await getUser(username);
    if (!u) throw new Error('User not found.');
    const salt = rnd();
    const h = await hash(password, salt);
    sqlite.run('UPDATE users SET salt = ?, hash = ? WHERE key = ?', [salt, h, u.key]);
    schedulePersist();
  }

  async function getUser(username) {
    await ensure();
    const res = sqlite.exec('SELECT key, username, name, emp_no, role, salt, hash, created FROM users WHERE key = ?', [keyOf(username)]);
    if (!res.length || !res[0].values.length) return null;
    return rowUser(res[0].values[0]);
  }

  async function updateUser(username, patch) {
    await ensure();
    const u = await getUser(username);
    if (!u) throw new Error('User not found.');
    if (patch.role && u.role === 'admin' && patch.role !== 'admin') {
      const admins = (await allUsers()).filter(x => x.role === 'admin');
      if (admins.length <= 1) throw new Error('At least one administrator must remain.');
    }
    const next = Object.assign({}, u, patch);
    if (patch.name != null) next.name = patch.name;
    if (patch.empNo != null) next.empNo = patch.empNo;
    if (patch.role != null) next.role = patch.role === 'admin' ? 'admin' : 'user';
    sqlite.run(
      'UPDATE users SET name = ?, emp_no = ?, role = ? WHERE key = ?',
      [next.name, next.empNo || '', next.role, u.key]
    );
    schedulePersist();
    return getUser(u.key);
  }

  async function removeUser(username) {
    await ensure();
    const u = await getUser(username);
    if (!u) return;
    if (u.role === 'admin') {
      const admins = (await allUsers()).filter(x => x.role === 'admin');
      if (admins.length <= 1) throw new Error('The last administrator cannot be removed.');
    }
    sqlite.run('DELETE FROM users WHERE key = ?', [u.key]);
    schedulePersist();
  }

  async function allUsers() {
    await ensure();
    const res = sqlite.exec('SELECT key, username, name, emp_no, role, salt, hash, created FROM users ORDER BY name');
    if (!res.length) return [];
    return res[0].values.map(rowUser);
  }

  /* ---------- auth / session ---------- */
  async function login(username, password) {
    await ensure();
    const lock = JSON.parse(localStorage.getItem('fs_lock') || '{}');
    if (lock.until && Date.now() < lock.until) {
      throw new Error('Too many failed attempts. Try again in ' + Math.ceil((lock.until - Date.now()) / 1000) + ' seconds.');
    }
    const u = await getUser(username);
    const ok = u && u.hash === await hash(password, u.salt);
    if (!ok) {
      const n = (lock.n || 0) + 1;
      localStorage.setItem('fs_lock', JSON.stringify(n >= CONFIG.maxFailedLogins
        ? { n: 0, until: Date.now() + CONFIG.lockSeconds * 1000 } : { n }));
      throw new Error('Incorrect username or password.');
    }
    localStorage.removeItem('fs_lock');
    const sess = { key: u.key, t: Date.now() };
    localStorage.setItem('fs_session', JSON.stringify(sess));
    sessionStorage.setItem('fs_session', JSON.stringify(sess));
    return u;
  }

  async function currentUser() {
    try {
      await ensure();
      let s = JSON.parse(localStorage.getItem('fs_session') || 'null')
            || JSON.parse(sessionStorage.getItem('fs_session') || 'null');
      if (!s) return null;
      const u = await getUser(s.key);
      if (!u) {
        localStorage.removeItem('fs_session');
        sessionStorage.removeItem('fs_session');
        return null;
      }
      localStorage.setItem('fs_session', JSON.stringify({ key: u.key, t: Date.now() }));
      sessionStorage.setItem('fs_session', JSON.stringify({ key: u.key, t: Date.now() }));
      return u;
    } catch (e) { return null; }
  }

  function logout() {
    localStorage.removeItem('fs_session');
    sessionStorage.removeItem('fs_session');
  }

  /* ---------- reports ---------- */
  async function reports() {
    await ensure();
    const res = sqlite.exec(
      `SELECT id, catcher, emp_no, lat, lng, release_lat, release_lng, site, release_loc,
              description, status, captured_at, released_at, created_by, created_at, environment, photo, has_photo
       FROM reports ORDER BY captured_at DESC`
    );
    if (!res.length) return [];
    const list = res[0].values.map(rowReport);
    // Attach photos from blob store (parallel limited)
    await Promise.all(list.map(async r => { await attachPhoto(r); }));
    return list;
  }

  async function getReport(id) {
    await ensure();
    const res = sqlite.exec(
      `SELECT id, catcher, emp_no, lat, lng, release_lat, release_lng, site, release_loc,
              description, status, captured_at, released_at, created_by, created_at, environment, photo, has_photo
       FROM reports WHERE id = ?`, [id]
    );
    if (!res.length || !res[0].values.length) return null;
    return attachPhoto(rowReport(res[0].values[0]));
  }

  async function saveReport(r) {
    await ensure();
    if (!r || !r.id) throw new Error('Report id is required.');
    // Persist photo outside SQLite so DB can grow toward multi-GB browser quota
    if (r.photo && String(r.photo).startsWith('data:')) {
      await photoPut(r.id, r.photo);
      r.has_photo = true;
    } else if (r.photo === null || r.photo === '') {
      await photoDel(r.id);
      r.has_photo = false;
    }
    insertReportRow(sqlite, r);
    schedulePersist();
  }

  async function deleteReport(id) {
    await ensure();
    sqlite.run('DELETE FROM reports WHERE id = ?', [id]);
    await photoDel(id);
    schedulePersist();
  }

  /* ---------- activity log (admin footprint) ---------- */
  async function logActivity(username, action, detail, reportId) {
    await ensure();
    sqlite.run(
      'INSERT INTO activity_log (at, username, action, detail, report_id) VALUES (?,?,?,?,?)',
      [new Date().toISOString(), username || '', action || '', detail || '', reportId || null]
    );
    // Keep last 5000 events
    sqlite.run('DELETE FROM activity_log WHERE id NOT IN (SELECT id FROM activity_log ORDER BY id DESC LIMIT 5000)');
    schedulePersist();
  }

  async function activityLogs(opts) {
    await ensure();
    opts = opts || {};
    let sql = 'SELECT id, at, username, action, detail, report_id FROM activity_log WHERE 1=1';
    const params = [];
    if (opts.username) { sql += ' AND username = ?'; params.push(opts.username); }
    if (opts.since) { sql += ' AND at >= ?'; params.push(opts.since); }
    sql += ' ORDER BY at DESC LIMIT ?';
    params.push(opts.limit || 300);
    const res = sqlite.exec(sql, params);
    if (!res.length) return [];
    return res[0].values.map(r => ({
      id: r[0], at: r[1], username: r[2], action: r[3], detail: r[4], reportId: r[5]
    }));
  }

  async function userFootprint(username) {
    await ensure();
    const key = username || '';
    const logs = await activityLogs({ username: key, limit: 200 });
    const reps = (await reports()).filter(r => (r.createdBy || '') === key || (r.catcher || '') === key);
    return { logs, reports: reps };
  }

  /* ---------- storage estimate (target multi-GB / ~5 GB when browser allows) ---------- */
  async function storageInfo() {
    const info = { used: 0, quota: 0, persistent: false, note: '' };
    try {
      if (navigator.storage && navigator.storage.estimate) {
        const e = await navigator.storage.estimate();
        info.used = e.usage || 0;
        info.quota = e.quota || 0;
      }
      if (navigator.storage && navigator.storage.persisted) {
        info.persistent = await navigator.storage.persisted();
      }
      if (navigator.storage && navigator.storage.persist && !info.persistent) {
        await navigator.storage.persist().catch(() => {});
        if (navigator.storage.persisted) info.persistent = await navigator.storage.persisted();
      }
      const gb = n => (n / (1024 * 1024 * 1024)).toFixed(2);
      info.note = `Using ${gb(info.used)} GB of ${gb(info.quota) || '?'} GB available` +
        (info.persistent ? ' (persistent storage granted)' : ' (requesting persistent storage)');
    } catch (e) {
      info.note = 'Storage estimate unavailable';
    }
    return info;
  }

  /* ---------- backup / restore ---------- */
  async function exportAll() {
    await ensure();
    const reps = await reports(); // includes photos from blob store
    return {
      app: 'fidelity-adt-snake-portal', version: 3, format: 'json',
      exported: new Date().toISOString(),
      users: await allUsers(),
      reports: reps,
      activity: await activityLogs({ limit: 5000 })
    };
  }

  async function exportSqlite() {
    await ensure();
    await persist();
    return sqlite.export();
  }

  async function importAll(data, replace) {
    await ensure();
    if (!data || data.app !== 'fidelity-adt-snake-portal') throw new Error('This is not a portal backup file.');
    if (replace) {
      sqlite.run('DELETE FROM reports');
      sqlite.run('DELETE FROM users');
      sqlite.run('DELETE FROM activity_log');
    }
    for (const u of data.users || []) {
      if (replace || !(await getUser(u.key || u.username))) insertUserRow(sqlite, u);
    }
    for (const r of data.reports || []) {
      if (replace || !(await getReport(r.id))) {
        insertReportRow(sqlite, r);
        if (r.photo && String(r.photo).startsWith('data:')) await photoPut(r.id, r.photo);
      }
    }
    for (const a of data.activity || []) {
      sqlite.run(
        'INSERT INTO activity_log (at, username, action, detail, report_id) VALUES (?,?,?,?,?)',
        [a.at || new Date().toISOString(), a.username || '', a.action || '', a.detail || '', a.reportId || a.report_id || null]
      );
    }
    schedulePersist();
    await persist();
    await ensureSeed();
  }

  async function importSqlite(buffer) {
    await ensure();
    const u8 = buffer instanceof Uint8Array ? buffer : new Uint8Array(buffer);
    const test = new SQL.Database(u8);
    const check = test.exec("SELECT name FROM sqlite_master WHERE type='table' AND name='reports'");
    if (!check.length) {
      test.close();
      throw new Error('This file is not a portal SQLite database.');
    }
    test.close();
    if (sqlite) sqlite.close();
    sqlite = new SQL.Database(u8);
    applySchema(sqlite);
    await persist();
    await ensureSeed();
  }

  return {
    ensureSeed, createUser, setPassword, updateUser, removeUser, allUsers,
    login, currentUser, logout, reports, saveReport, deleteReport, getReport,
    exportAll, importAll, exportSqlite, importSqlite, hash, keyOf, persist,
    logActivity, activityLogs, userFootprint, storageInfo
  };
})();

/* Make the globals explicit (survives Cloudflare Rocket Loader / eval-style script loading) */
window.CONFIG = CONFIG;
window.DBLocal = DBLocal;   // js/cloud.js decides whether the portal uses the shared cloud database or this local one
